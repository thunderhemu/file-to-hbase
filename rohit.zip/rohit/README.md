# FileCompactor
  This application compacts the part file of a given path

## Table of Contents
* [General info](#general-info)
* [Execution options](#execution-options)
* [Compaction ratio formula](#compaction-ratio-formula)
* [Set up local env for tests](#set-up-local-env-for-tests)
* [Project structure](#project-structure)
* [Future scope](#future-scope)

## General info
   This application compacts the part file of a given path, it copies data to temp location 
   and read it from temp location and over writes the input path with part file calculated based on the size 

### config file 
    