import mysql.connector


class Mysql:
    def __init__(self, app_configs, args):
        self.args = args
        self.env = args.env
        self.user = app_configs[self.env]["mysql-cdb-user"]
        self.password = app_configs[self.env]["mysql-cdb-pass"]
        self.host = app_configs[self.env]["mysql-server-name"]
        self.db_name = app_configs[self.env]["mysqlcdb-name"]
        self.profile_table = app_configs[self.env]["mysqlcdb-profile-table"]
        self.aml_instance_table = app_configs[self.env]["mysqlcdb-aml-instance-table"]
        self.aml_compute_table = app_configs[self.env]["mysqlcdb-aml_compute_table"]
        print(self.host, self.user, self.password, self.db_name)

    def connect_to_db(self):
        db = mysql.connector.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.db_name
        )
        return db

    def read_profiles(self):
        db = self.connect_to_db()
        res = []

        try:
            cursor = db.cursor()
            cursor.execute(" select * from  {}.{} where CIProfileID= {}".
                           format(self.db_name, self.profile_table, self.args.ci_profile_id))
            result = cursor.fetchall()

            for x in result:
                print(x)
                res.append(x)
        except Exception as e:
            print("Error: Query to profile table failed")
            print(e)
            return None
        return res

    def read_aml_instances(self):
        db = self.connect_to_db()
        res = []

        try:
            cursor = db.cursor()
            cursor.execute("SELECT * FROM {}.{} where InstanceName = '{} order by limit 1".
                           format(self.db_name, self.aml_instance_table, self.args.aml_instance_name))
            result = cursor.fetchall()

            for x in result:
                print(x)
                res.append(x)
        except Exception as e:
            print(e)
            return None

        return res

    def insert_aml_instance(self, instance_id, cc_name, ci_profiles_id,
                            min_scale, max_scale, cc_created_date,  cc_deleted_date):
        db = self.connect_to_db()

        try:
            cursor = db.cursor()

            sql = """
                    INSERT INTO %s.%s 
                    (AMLInstanceID,
                        CCName,
                      CIProfileID,
                      MinScale,
                      MaxScale,
                      CCCreateDate,
                      CCDeleteDate
                      ) 
                    VALUES (%s,%s,%s,%s,%s,%s,%s)
                    """
            val = (self.db_name, self.aml_instance_table, instance_id, cc_name, ci_profiles_id, min_scale, max_scale,
                   cc_created_date,  cc_deleted_date)
            cursor.execute(sql, val)
            db.commit()
            instance_id = cursor.lastrowid
        except Exception as e:
            print(e)
            return None

        print("AML Instance with id {} created".format(instance_id))
        return instance_id

    def update_aml_instance(self, instance_id, ci_profiles_id, cc_deleted_date):
        db = self.connect_to_db()

        try:
            cursor = db.cursor()

            sql = """
                UPDATE %s.%s
                SET CCDeleteDate = %s
                WHERE AMLInstanceID = %s and CIProfileID = %s
                """
            val = (self.db_name, self.aml_instance_table, cc_deleted_date, instance_id, ci_profiles_id)
            cursor.execute(sql, val)

            db.commit()
        except Exception as e:
            print(e)
            return None

        return "{} records Updated.".format(cursor.rowcount)
