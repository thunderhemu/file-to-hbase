import sys


def validate_aml_instance(aml_instance_data, args):
    if aml_instance_data['InstanceOwner'].tolower() != args.owner.tolower():
        print("Error: Invalid owner, the supplied owner doesn't match with aml instance")
        # TODO
    if aml_instance_data['InstanceProjectID'] != args.project_id:
        print("Error: Invalid project id, the supplied project id doesn't match with aml instance")
        # TODO
    if aml_instance_data['InstanceBillCode'] != args.bill_code:
        print("Error: Invalid project id, the supplied project id doesn't match with aml instance")
        # TODO


def validate_ci_profiles(cpu_type, az_vm_type):
    """

    :param cpu_type:
    :param az_vm_type:
    :return:
    """
    if cpu_type.lower() not in ('c', 'g'):
        print("Error: Invalid  cpu type")
        print("Exiting")
        sys.exit(-1)

    if az_vm_type.lower() not in ("standard_ds2_v2", "standard_ds1_v2", "standard_ds0_v2"):
        print("Error: Invalid  vm type")
        print("Exiting")
        sys.exit(-1)

    return "cpu" if cpu_type.lower() == 'c' else "gpu", \
           "Standard_DS2_v2" if az_vm_type.lower() == "standard_ds2_v2" else "Standard_DS1_v2" \
               if az_vm_type.lower() == "standard_ds1_v2" else "Standard_DS0_v2" ,
