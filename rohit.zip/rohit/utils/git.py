import subprocess
import sys

import git

class Git:

    def __init__(self, app_configs):
        self.repo_url = app_configs['terraform']['repo-url']

    def clone_terraform_repo(self):
        """
        Clone repo that stores teraform templates
        """
        with subprocess.Popen("""git clone {}""".format(self.repo_url), shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
            if cmd.returncode != 0:
                print("Error: failed to clone the git repo")
                sys.exit(-1)
            return cmd_res

    def update_terraform_repo(self, src_file_path, dest_file_path):
        """
        Add files to repo.
        Args:
            src_file_path (string): file to add to the repo
            dest_file_path (string): repo destination for file
        """
        with subprocess.Popen("""cp {} {}""".format(src_file_path, dest_file_path),
                              shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
            return cmd_res

    def push_teraform_repo(self):
        """
        Push to online repo.
        """
        with subprocess.Popen("git add .") as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
            print(cmd_res)

        with subprocess.Popen("git push", shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
            return cmd_res


x = git.Repo.clone_from()
x.index.add()