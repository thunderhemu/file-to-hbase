import subprocess
import re
import os
import sys

from utils.git import Git
import datetime


def get_current_date():
    return datetime.date.today()


class Terraform:
    def __init__(self, app_configs, args, workspace_name, work_space_resource_group_name,
                 az_vm_type):
        self.env = args.env
        self.app_configs = app_configs
        self.mappings = {}
        self.tf_vars_file_name = 'terraform.tfvars'
        self.work_dir_path = app_configs[self.env]['working-dir']
        os.chdir(self.work_dir_path)
        self.terraform_local_path = app_configs[self.env]['terraform_dir']
        self.subscription_id = args.az_sub_id
        self.location = args.azure_location
        self.virtual_network_name = args.vnet
        self.subnet_name = args.sub_net
        self.network_resource_group_name = args.net_rg
        self.work_space_name = workspace_name
        self.work_space_resource_group_name = work_space_resource_group_name
        self.compute_cluster_name = args.aml_compute_cluster_name
        self.priority = args.vm_priority
        self.vm_size = az_vm_type
        self.min_node = args.min_nodes
        self.max_node = args.max_nodes
        self.scale_down_time = args.vm_scale_down_time

    def create_tf_vars_file(self):
        """
         create new tfvars file with replaced vatiables
        :return:
        """
        git = Git(self.app_configs)
        git_clone = git.clone_terraform_repo()
        print("Info: Git repo cloning done ")

        with open(os.getcwd() + '/' + self.terraform_local_path, 'r') as f:
            changed_text = f.read().replace('var-subscription_id', self.subscription_id) \
                                   .replace('var-location', self.location) \
                                   .replace('var-VirtualNetworkName', self.virtual_network_name) \
                                   .replace('var-SubnetName', self.subnet_name) \
                                   .replace('var-NetworkResourceGroupName', self.network_resource_group_name) \
                                   .replace('var-WorkSpaceName', self.work_space_name) \
                                   .replace('var-WorkspaceResourceGroupName', self.work_space_resource_group_name) \
                                   .replace('var-compute_cluster_name', self.compute_cluster_name) \
                                   .replace('var-priority', self.priority) \
                                   .replace('var-vmsize', self.vm_size) \
                                   .replace('var.min_node', self.min_node) \
                                   .replace('var.scale_down_time', self.max_node)

        with open(os.getcwd() + '/' + self.terraform_local_path, "w") as f:
            f.write(changed_text)
        print("Info: tfvars has been updated with latest vars ")

    def terraform_apply(self):
        cwd = os.getcwd()
        os.chdir(cwd + '/' + self.terraform_local_path)
        with subprocess.Popen("terraform init", shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
        if cmd.returncode != 0:
            print("Error Command terraform init failed:")
            print(cmd)
            sys.exit(-1)
        with subprocess.Popen("terraform apply -auto-approve", shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
        os.chdir(cwd)
        if cmd.returncode != 0:
            print("Error Command apply -auto-approve failed:")
            print(cmd)
            sys.exit(-1)
        return get_current_date(self)

    def get_terraform_state(self, path, var_name):

        with subprocess.Popen("cd {} && terraform state show {}".format(
                self.terraform_repo_folder, path, var_name),
                shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')

            p = re.compile('{}.*'.format(var_name))
            return p.findall(cmd_res)[0].split("\"")[1]

    def _get_terraform_output(self, var_name):
        with subprocess.Popen("cd {} && terraform output -json {}".format(
                self.terraform_repo_folder, var_name), shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')
            return cmd_res

    def get_aml_instance_name(self):
        self._get_terraform_state(self.terraform_aml_path, "name")

    def get_aml_resource_group_name(self):
        self._get_terraform_state(self.terraform_aml_rg_path, "name")

    def get_aml_wasb_storage_id(self):
        self._get_terraform_state(self.terraform_wasb_strg_path, "id")

    def destroy_all_resources(self, workspace):
        with subprocess.Popen("cd {} && terraform workspace select {} && terraform destroy -auto-approve".format(
                self.terraform_repo_folder, workspace),
                shell=True, stdout=subprocess.PIPE) as cmd:
            cmd_res = cmd.stdout.read().decode('utf-8')

            return cmd_res

