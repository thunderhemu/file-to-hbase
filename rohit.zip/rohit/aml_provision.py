import configparser
import argparse
from utils.terraform import Terraform
from utils.mysql import Mysql
from utils import table_validations


def parse_config(file_name):
    """
    parses the config file
    :param file_name: config file anme
    :return:  None
    """
    config = configparser.ConfigParser()
    config.read(file_name)


def start_prcoess(args, config):
    """

    :param args:
    :param config:
    :return:
    """
    mysql = Mysql(config, args)
    ci_profiles_data = mysql.read_profiles()
    aml_instance_data = mysql.read_aml_instances()
    cpu_type = ci_profiles_data["CPUType"]
    az_vm_type = ci_profiles_data["AZVMType"]
    cpu_type, az_vm_type = table_validations.validate_ci_profiles(cpu_type, az_vm_type)
    table_validations.validate_aml_instance(aml_instance_data, args)
    compute_cluster_name = args.aml_compute_cluster_name
    max_nodes = args.max_nodes
    min_nodes = args.min_nodes
    ci_profile_id = ci_profiles_data['CIProfileID']
    aml_instance_id = aml_instance_data['InstanceID']
    terraform = Terraform(config, args, aml_instance_data['InstanceName'], aml_instance_data["InstanceRG"], az_vm_type)
    terraform.create_tf_vars_file()
    created_date = terraform.terraform_apply()
    mysql.insert_aml_instance(aml_instance_id, compute_cluster_name, ci_profile_id, min_nodes, max_nodes, created_date)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Instance Creator')
    parser.add_argument('--configFile', help='config file to parse', required=True)
    parser.add_argument('--aml-instance-name', help='aml instance name', required=True)
    parser.add_argument('--aml-compute-cluster-name', help='aml cluster name', required=True)
    parser.add_argument('--min-nodes', help='aml cluster name', required=True)
    parser.add_argument('--max-nodes', help='aml cluster name', required=True)
    parser.add_argument('--azure-location', help='aml cluster name', required=True)
    parser.add_argument('--vnet', help='aml cluster name', required=True)
    parser.add_argument('--subnet', help='aml cluster name', required=True)
    parser.add_argument('--az-sub-id', help='aml cluster name', required=True)
    parser.add_argument('--net-rg', help='aml cluster name', required=True)
    parser.add_argument('--vm-priority', help='aml cluster name', required=True)
    parser.add_argument('--vm-scale-down-time', help='aml cluster name', required=True)
    parser.add_argument('--ci-profile-id', help='aml cluster name', required=True)
    parser.add_argument('--env', help='aml cluster name', required=True)
    parser.add_argument('--owner', help='aml cluster name', required=False)
    parser.add_argument('--project-id', help='aml cluster name', required=False)
    parser.add_argument('--bill-code', help='aml cluster name', required=False)
    args = parser.parse_args()
    start_prcoess(args,  parse_config(args.configFile))


